# UserAgent 匹配归类

## 配置示例

```
filter {
    useragent {
        target => "ua"
        source => "useragent"
    }
}
```
