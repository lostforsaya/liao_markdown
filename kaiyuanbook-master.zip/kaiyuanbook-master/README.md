# Software Development Book Contents#

[![Build Status](https://secure.travis-ci.org/larrycai/kaiyuanbook.png)](http://travis-ci.org/larrycai/kaiyuanbook)

This is the book for how to write opensource books, it covers markdown,pandoc,latex

Hope you enjoy it, I hope it helps you learn better software development. 

Please check BUILD.md for how to making ebooks by yourself, 

credit to [Pro Git](http://github.com/progit/progit) 

#Errata#

If you see anything that is technically wrong or otherwise in need of
correction, please email me at larry dot caiyu at gmail dot com to inform me.

### License
  The license is under ![](http://i.creativecommons.org/l/by-nc-nd/3.0/88x31.png), see [CC BY NC ND 3.0](http://creativecommons.org/licenses/by-nc-nd/3.0/) for more

